/* ==========================================================================
 * Unit: dtc_mgr (SWU-007)
 * Parent (SWE.2): SWD-CMP-007 Fault & DTC Manager
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-014; SwRS-029; SwRS-030 | SWE.2 SWD-CMP-007 Fault & DTC Manager
 * ========================================================================== */
#ifndef DTC_MGR_H
#define DTC_MGR_H
#include "types.h"
#include "config.h"
void DTC_Set(uint16_t code, const Snapshot_t* snap);

/* Test hooks */

#endif /* DTC_MGR_H */
