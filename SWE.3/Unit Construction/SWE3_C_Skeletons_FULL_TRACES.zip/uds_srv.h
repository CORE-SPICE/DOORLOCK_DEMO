/* ==========================================================================
 * Unit: uds_srv (SWU-006)
 * Parent (SWE.2): SWD-CMP-006 Diagnostics UDS
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-009; SwRS-027; SwRS-020; SwRS-029 | SWE.2 SWD-CMP-006 Diagnostics UDS
 * ========================================================================== */
#ifndef UDS_SRV_H
#define UDS_SRV_H
#include "types.h"
#include "config.h"
void UDS_Init(void);
void UDS_Dispatch(const CANMsg_t* req, CANMsg_t* resp);

/* Test hooks */

#endif /* UDS_SRV_H */
