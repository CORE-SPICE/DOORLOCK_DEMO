/* ==========================================================================
 * Unit: bootloader (SWU-016) - implementation
 * Trace: SWE.1 SwRS-012; SwRS-026 | SWE.2 SWD-CMP-016 Bootloader
 * ========================================================================== */
#include "bootloader.h"

bool BL_Apply(const Image_t* img) {
    /* TODO: implement */
}

