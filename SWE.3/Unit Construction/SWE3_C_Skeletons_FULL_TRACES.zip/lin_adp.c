/* ==========================================================================
 * Unit: lin_adp (SWU-012) - implementation
 * Trace: SWE.1 SwRS-015 | SWE.2 SWD-CMP-012 LIN Adapter
 * ========================================================================== */
#include "lin_adp.h"

void LIN_If_Tx(const uint8_t* data, size_t len) {
    /* TODO: implement */
}

size_t LIN_If_Rx(uint8_t* data, size_t maxlen) {
    /* TODO: implement */
}

