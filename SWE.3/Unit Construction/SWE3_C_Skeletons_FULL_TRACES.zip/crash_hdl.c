/* ==========================================================================
 * Unit: crash_hdl (SWU-005) - implementation
 * Trace: SWE.1 SwRS-007; SwRS-024 | SWE.2 SWD-CMP-005 Crash Handler
 * ========================================================================== */
#include "crash_hdl.h"

void CRASH_OnSignal(bool asserted) {
    /* TODO: implement */
}

