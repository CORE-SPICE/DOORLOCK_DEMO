/* ==========================================================================
 * Unit: crash_hdl (SWU-005)
 * Parent (SWE.2): SWD-CMP-005 Crash Handler
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-007; SwRS-024 | SWE.2 SWD-CMP-005 Crash Handler
 * ========================================================================== */
#ifndef CRASH_HDL_H
#define CRASH_HDL_H
#include "types.h"
#include "config.h"
void CRASH_OnSignal(bool asserted);

/* Test hooks */

#endif /* CRASH_HDL_H */
