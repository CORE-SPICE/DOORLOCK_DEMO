Door Lock Control ECU — SWE.4 C Skeletons
-----------------------------------------
Generated from SWE.3 Detailed Design. Trace IDs are embedded in each file header.
Build (example):
  mkdir build && cd build
  cmake .. && cmake --build .
