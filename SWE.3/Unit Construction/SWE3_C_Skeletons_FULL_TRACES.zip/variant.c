/* ==========================================================================
 * Unit: variant (SWU-017) - implementation
 * Trace: SWE.1 SwRS-022 | SWE.2 SWD-CMP-017 Variant Manager
 * ========================================================================== */
#include "variant.h"

Variant_t VAR_Get(void) {
    /* TODO: implement */
}

