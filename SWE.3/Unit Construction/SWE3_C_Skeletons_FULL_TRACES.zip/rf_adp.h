/* ==========================================================================
 * Unit: rf_adp (SWU-013)
 * Parent (SWE.2): SWD-CMP-013 RF Receiver Adapter
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-006; SwRS-013 | SWE.2 SWD-CMP-013 RF Receiver Adapter
 * ========================================================================== */
#ifndef RF_ADP_H
#define RF_ADP_H
#include "types.h"
#include "config.h"
bool RF_Parse(const uint8_t* raw, size_t len, RFFrame_t* out);

/* Test hooks */

#endif /* RF_ADP_H */
