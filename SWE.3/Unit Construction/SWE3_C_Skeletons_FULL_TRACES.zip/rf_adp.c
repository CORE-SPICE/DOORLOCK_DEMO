/* ==========================================================================
 * Unit: rf_adp (SWU-013) - implementation
 * Trace: SWE.1 SwRS-006; SwRS-013 | SWE.2 SWD-CMP-013 RF Receiver Adapter
 * ========================================================================== */
#include "rf_adp.h"

bool RF_Parse(const uint8_t* raw, size_t len, RFFrame_t* out) {
    /* TODO: implement */
}

