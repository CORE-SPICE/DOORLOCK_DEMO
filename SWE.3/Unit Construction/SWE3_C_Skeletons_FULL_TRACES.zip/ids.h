/* ==========================================================================
 * Unit: ids (SWU-010)
 * Parent (SWE.2): SWD-CMP-010 IDS Engine
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-013; SwRS-025; SwRS-030 | SWE.2 SWD-CMP-010 IDS Engine
 * ========================================================================== */
#ifndef IDS_H
#define IDS_H
#include "types.h"
#include "config.h"
void IDS_OnRF(const RFFrame_t* f);
void IDS_OnCAN(const CANMsg_t* m);

/* Test hooks */
#if TESTING
void IDS_SET_THRESHOLD(uint8_t window);
#endif

#endif /* IDS_H */
