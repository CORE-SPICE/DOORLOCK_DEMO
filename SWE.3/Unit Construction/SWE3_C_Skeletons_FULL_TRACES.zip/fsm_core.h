/* ==========================================================================
 * Unit: fsm_core (SWU-001)
 * Parent (SWE.2): SWD-CMP-001 State Machine Core
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-001; SwRS-018; SwRS-024 | SWE.2 SWD-CMP-001 State Machine Core
 * ========================================================================== */
#ifndef FSM_CORE_H
#define FSM_CORE_H
#include "types.h"
#include "config.h"
void FSM_Init(const Variant_t* cfg);
void FSM_HandleCommand(Cmd_t cmd);

/* Test hooks */
#if TESTING
Cmd_t FSM_EXPORT_STATE(void);
#endif

#endif /* FSM_CORE_H */
