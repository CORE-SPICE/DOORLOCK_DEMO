/* ==========================================================================
 * Unit: act_mgr (SWU-003) - implementation
 * Trace: SWE.1 SwRS-004; SwRS-005; SwRS-020 | SWE.2 SWD-CMP-003 Actuator Manager
 * ========================================================================== */
#include "act_mgr.h"

void ACT_StartPulse(Direction dir, uint16_t duration_ms) {
    /* TODO: implement */
}

void ACT_Stop(void) {
    /* TODO: implement */
}

#if TESTING
void ACT_INJECT_OC(void){}
#endif

