/* ==========================================================================
 * Unit: can_adp (SWU-011) - implementation
 * Trace: SWE.1 SwRS-010; SwRS-019; SwRS-025 | SWE.2 SWD-CMP-011 CAN Stack Adapter
 * ========================================================================== */
#include "can_adp.h"

bool CAN_Validate(const CANMsg_t* m) {
    /* TODO: implement */
}

