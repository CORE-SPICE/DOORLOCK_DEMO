/* ==========================================================================
 * Unit: mcu_hal (SWU-014) - implementation
 * Trace: SWE.1 SwRS-017; SwRS-023; SwRS-024 | SWE.2 SWD-CMP-014 MCU HAL
 * ========================================================================== */
#include "mcu_hal.h"

uint32_t HAL_GetTickMs(void) {
    /* TODO: implement */
}

uint16_t HAL_GetVBATmV(void) {
    /* TODO: implement */
}

void HAL_WatchdogKick(void) {
    /* TODO: implement */
}

