/* ==========================================================================
 * Unit: bootloader (SWU-016)
 * Parent (SWE.2): SWD-CMP-016 Bootloader
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-012; SwRS-026 | SWE.2 SWD-CMP-016 Bootloader
 * ========================================================================== */
#ifndef BOOTLOADER_H
#define BOOTLOADER_H
#include "types.h"
#include "config.h"
bool BL_Apply(const Image_t* img);

/* Test hooks */

#endif /* BOOTLOADER_H */
