/* ==========================================================================
 * Unit: in_filter (SWU-004) - implementation
 * Trace: SWE.1 SwRS-003 | SWE.2 SWD-CMP-004 Input Filter
 * ========================================================================== */
#include "in_filter.h"

bool IN_DebounceTick(bool raw) {
    /* TODO: implement */
}

