/* ==========================================================================
 * Unit: nvm_svc (SWU-008)
 * Parent (SWE.2): SWD-CMP-008 NVM Service
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-014; SwRS-021 | SWE.2 SWD-CMP-008 NVM Service
 * ========================================================================== */
#ifndef NVM_SVC_H
#define NVM_SVC_H
#include "types.h"
#include "config.h"
bool NVM_Write(uint32_t id, const void* data, size_t len);
bool NVM_Read(uint32_t id, void* data, size_t len);

/* Test hooks */
#if TESTING
void NVM_FAULT_MODE(bool enable);
#endif

#endif /* NVM_SVC_H */
