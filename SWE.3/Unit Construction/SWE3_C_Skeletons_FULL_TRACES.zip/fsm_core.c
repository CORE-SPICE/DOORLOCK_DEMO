/* ==========================================================================
 * Unit: fsm_core (SWU-001) - implementation
 * Trace: SWE.1 SwRS-001; SwRS-018; SwRS-024 | SWE.2 SWD-CMP-001 State Machine Core
 * ========================================================================== */
#include "fsm_core.h"

void FSM_Init(const Variant_t* cfg) {
    /* TODO: implement */
}

void FSM_HandleCommand(Cmd_t cmd) {
    /* TODO: implement */
}

#if TESTING
Cmd_t FSM_EXPORT_STATE(void){ return CMD_NONE; }
#endif

