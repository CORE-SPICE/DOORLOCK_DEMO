/* ==========================================================================
 * Unit: lin_adp (SWU-012)
 * Parent (SWE.2): SWD-CMP-012 LIN Adapter
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-015 | SWE.2 SWD-CMP-012 LIN Adapter
 * ========================================================================== */
#ifndef LIN_ADP_H
#define LIN_ADP_H
#include "types.h"
#include "config.h"
void LIN_If_Tx(const uint8_t* data, size_t len);
size_t LIN_If_Rx(uint8_t* data, size_t maxlen);

/* Test hooks */

#endif /* LIN_ADP_H */
