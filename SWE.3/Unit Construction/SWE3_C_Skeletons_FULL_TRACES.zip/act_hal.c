/* ==========================================================================
 * Unit: act_hal (SWU-015) - implementation
 * Trace: SWE.1 SwRS-003; SwRS-004; SwRS-005 | SWE.2 SWD-CMP-015 Actuator Driver HAL
 * ========================================================================== */
#include "act_hal.h"

void HAL_MotorDrive(Direction dir) {
    /* TODO: implement */
}

void HAL_MotorStop(void) {
    /* TODO: implement */
}

uint16_t HAL_CurrentSense_mA(void) {
    /* TODO: implement */
}

