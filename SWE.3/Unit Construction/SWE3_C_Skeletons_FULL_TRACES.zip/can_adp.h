/* ==========================================================================
 * Unit: can_adp (SWU-011)
 * Parent (SWE.2): SWD-CMP-011 CAN Stack Adapter
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-010; SwRS-019; SwRS-025 | SWE.2 SWD-CMP-011 CAN Stack Adapter
 * ========================================================================== */
#ifndef CAN_ADP_H
#define CAN_ADP_H
#include "types.h"
#include "config.h"
bool CAN_Validate(const CANMsg_t* m);

/* Test hooks */

#endif /* CAN_ADP_H */
