/* ==========================================================================
 * File: config.h
 * Trace: SwRS-003, SwRS-004, SwRS-005, SwRS-008, SwRS-013
 * ========================================================================== */
#ifndef CONFIG_H
#define CONFIG_H
#ifndef TESTING
#define TESTING 0
#endif
#define CAL_DEBOUNCE_MS        (50u)
#define CAL_PULSE_MS_LOCK      (300u)
#define CAL_PULSE_MS_UNLOCK    (350u)
#define CAL_OC_THRESHOLD_MA    (3000u)
#define CAL_IDS_REPLAY_WINDOW  (32u)
#define CAL_LOW_VOLT_ENTER_mV  (9000u)
#define CAL_LOW_VOLT_EXIT_mV   (9500u)
#endif /* CONFIG_H */
