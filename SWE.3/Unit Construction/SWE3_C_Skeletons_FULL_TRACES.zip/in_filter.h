/* ==========================================================================
 * Unit: in_filter (SWU-004)
 * Parent (SWE.2): SWD-CMP-004 Input Filter
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-003 | SWE.2 SWD-CMP-004 Input Filter
 * ========================================================================== */
#ifndef IN_FILTER_H
#define IN_FILTER_H
#include "types.h"
#include "config.h"
bool IN_DebounceTick(bool raw);

/* Test hooks */

#endif /* IN_FILTER_H */
