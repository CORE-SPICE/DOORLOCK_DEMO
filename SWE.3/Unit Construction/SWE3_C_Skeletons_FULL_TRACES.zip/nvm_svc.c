/* ==========================================================================
 * Unit: nvm_svc (SWU-008) - implementation
 * Trace: SWE.1 SwRS-014; SwRS-021 | SWE.2 SWD-CMP-008 NVM Service
 * ========================================================================== */
#include "nvm_svc.h"

bool NVM_Write(uint32_t id, const void* data, size_t len) {
    /* TODO: implement */
}

bool NVM_Read(uint32_t id, void* data, size_t len) {
    /* TODO: implement */
}

#if TESTING
void NVM_FAULT_MODE(bool enable){ (void)enable; }
#endif

