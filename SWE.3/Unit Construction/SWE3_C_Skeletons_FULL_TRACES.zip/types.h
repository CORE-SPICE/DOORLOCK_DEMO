/* ==========================================================================
 * File: types.h
 * Project: Door Lock Control ECU
 * Purpose: Shared software types for SWE.3/SWE.4 units.
 * Trace: SWE.1 (SwRS): SwRS-002, SwRS-003, SwRS-004, SwRS-005, SwRS-006, SwRS-009, SwRS-010, SwRS-011, SwRS-012, SwRS-013, SwRS-014, SwRS-019, SwRS-020, SwRS-021, SwRS-022, SwRS-023, SwRS-024, SwRS-025, SwRS-026, SwRS-027, SwRS-029, SwRS-030
 * ========================================================================== */
#ifndef TYPES_H
#define TYPES_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

typedef enum { CMD_NONE=0, CMD_LOCK, CMD_UNLOCK, CMD_TEST } Cmd_t;
typedef enum { DIR_LOCK=0, DIR_UNLOCK } Direction;

typedef struct { uint32_t counter; uint8_t payload[8]; uint32_t mac; } RFFrame_t;
typedef struct { uint32_t id; uint8_t dlc; uint8_t data[64]; uint8_t seq; } CANMsg_t;

typedef struct { uint16_t duration_ms; Direction direction; } PulseCfg_t;
typedef struct { uint16_t id; uint8_t snapshot[32]; uint32_t ts; } DTC_t;
typedef struct { uint32_t ts; uint16_t voltage_mV; uint16_t current_mA; uint8_t state; uint8_t reserved; } Snapshot_t;
typedef struct { uint32_t len; const uint8_t* data; uint32_t crc; } Image_t;
typedef struct { uint8_t doors; bool lin_enabled; } Variant_t;

typedef enum { ERR_NONE=0, ERR_RANGE, ERR_OC, ERR_REPLAY, ERR_QFULL } err_code_t;

#endif /* TYPES_H */
