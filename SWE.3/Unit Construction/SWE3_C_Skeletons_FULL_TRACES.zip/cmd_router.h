/* ==========================================================================
 * Unit: cmd_router (SWU-002)
 * Parent (SWE.2): SWD-CMP-002 Command Router
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-002; SwRS-018 | SWE.2 SWD-CMP-002 Command Router
 * ========================================================================== */
#ifndef CMD_ROUTER_H
#define CMD_ROUTER_H
#include "types.h"
#include "config.h"
void CMD_PushRF(const RFFrame_t* f);
void CMD_PushCAN(const CANMsg_t* m);

/* Test hooks */

#endif /* CMD_ROUTER_H */
