/* ==========================================================================
 * Unit: cmd_router (SWU-002) - implementation
 * Trace: SWE.1 SwRS-002; SwRS-018 | SWE.2 SWD-CMP-002 Command Router
 * ========================================================================== */
#include "cmd_router.h"

void CMD_PushRF(const RFFrame_t* f) {
    /* TODO: implement */
}

void CMD_PushCAN(const CANMsg_t* m) {
    /* TODO: implement */
}

