/* ==========================================================================
 * Unit: variant (SWU-017)
 * Parent (SWE.2): SWD-CMP-017 Variant Manager
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-022 | SWE.2 SWD-CMP-017 Variant Manager
 * ========================================================================== */
#ifndef VARIANT_H
#define VARIANT_H
#include "types.h"
#include "config.h"
Variant_t VAR_Get(void);

/* Test hooks */

#endif /* VARIANT_H */
