/* ==========================================================================
 * Unit: ids (SWU-010) - implementation
 * Trace: SWE.1 SwRS-013; SwRS-025; SwRS-030 | SWE.2 SWD-CMP-010 IDS Engine
 * ========================================================================== */
#include "ids.h"

void IDS_OnRF(const RFFrame_t* f) {
    /* TODO: implement */
}

void IDS_OnCAN(const CANMsg_t* m) {
    /* TODO: implement */
}

#if TESTING
void IDS_SET_THRESHOLD(uint8_t window){ (void)window; }
#endif

