/* ==========================================================================
 * Unit: uds_srv (SWU-006) - implementation
 * Trace: SWE.1 SwRS-009; SwRS-027; SwRS-020; SwRS-029 | SWE.2 SWD-CMP-006 Diagnostics UDS
 * ========================================================================== */
#include "uds_srv.h"

void UDS_Init(void) {
    /* TODO: implement */
}

void UDS_Dispatch(const CANMsg_t* req, CANMsg_t* resp) {
    /* TODO: implement */
}

