/* ==========================================================================
 * Unit: crypto (SWU-009)
 * Parent (SWE.2): SWD-CMP-009 Secure Boot & Crypto
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-011; SwRS-012; SwRS-026 | SWE.2 SWD-CMP-009 Secure Boot & Crypto
 * ========================================================================== */
#ifndef CRYPTO_H
#define CRYPTO_H
#include "types.h"
#include "config.h"
bool CRYPTO_VerifyImage(const Image_t* img);

/* Test hooks */
#if TESTING
void CRYPTO_INJECT_FAIL(void);
#endif

#endif /* CRYPTO_H */
