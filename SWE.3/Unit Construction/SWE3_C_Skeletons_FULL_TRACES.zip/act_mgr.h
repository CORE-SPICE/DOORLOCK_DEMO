/* ==========================================================================
 * Unit: act_mgr (SWU-003)
 * Parent (SWE.2): SWD-CMP-003 Actuator Manager
 * Purpose: C skeleton for SWE.4 implementation
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-004; SwRS-005; SwRS-020 | SWE.2 SWD-CMP-003 Actuator Manager
 * ========================================================================== */
#ifndef ACT_MGR_H
#define ACT_MGR_H
#include "types.h"
#include "config.h"
void ACT_StartPulse(Direction dir, uint16_t duration_ms);
void ACT_Stop(void);

/* Test hooks */
#if TESTING
void ACT_INJECT_OC(void);
#endif

#endif /* ACT_MGR_H */
