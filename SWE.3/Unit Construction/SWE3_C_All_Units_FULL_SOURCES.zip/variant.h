/* ==========================================================================
 * Unit: variant (SWU-017)
 * Parent (SWE.2): SWD-CMP-017 Variant Manager
 * Purpose: Provide variant flags (2/4 doors, LIN enable) backed by NVM
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-022 | SWE.2 SWD-CMP-017
 * ========================================================================== */
#ifndef VARIANT_H
#define VARIANT_H
#include "types.h"
#ifdef __cplusplus
extern "C" {
#endif

Variant_t VAR_Get(void);

#ifdef __cplusplus
}
#endif
#endif /* VARIANT_H */
