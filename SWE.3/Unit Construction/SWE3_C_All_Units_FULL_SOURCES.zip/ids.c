/* ==========================================================================
 * Unit: ids (SWU-010) - implementation
 * Trace: SWE.1 SwRS-013, SwRS-025, SwRS-030 | SWE.2 SWD-CMP-010
 * ========================================================================== */
#include "ids.h"
#include "config.h"
#include "dtc_mgr.h"

static uint32_t s_last_rf_counter = 0u;
static uint8_t s_window = CAL_IDS_REPLAY_WINDOW;
static uint8_t s_can_errors = 0u;

void IDS_Init(void)
{
    s_last_rf_counter = 0u;
    s_window = CAL_IDS_REPLAY_WINDOW;
    s_can_errors = 0u;
}

void IDS_OnRF(const RFFrame_t* f)
{
    if (f == 0) return;
    if (f->counter + s_window <= s_last_rf_counter) {
        Snapshot_t snap = {0};
        snap.ts = 0u;
        DTC_Set(0x0201u, &snap); /* SEC_REPLAY */
        return;
    }
    if (f->counter > s_last_rf_counter) {
        s_last_rf_counter = f->counter;
    }
}

void IDS_OnCAN(const CANMsg_t* m)
{
    if (m == 0) return;
    /* Simple heuristic: if DLC > 64 or seq goes backwards -> error */
    if (m->dlc > 64u) {
        s_can_errors++;
    }
    /* Error burst detection */
    if (s_can_errors > 10u) {
        Snapshot_t snap = {0};
        DTC_Set(0x0202u, &snap); /* SEC_CAN_ANOMALY */
        s_can_errors = 0u;
    }
}

#if TESTING
void IDS_SET_THRESHOLD(uint8_t window) { s_window = window; }
#endif
