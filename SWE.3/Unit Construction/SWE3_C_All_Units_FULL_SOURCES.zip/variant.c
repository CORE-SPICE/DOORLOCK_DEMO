/* ==========================================================================
 * Unit: variant (SWU-017) - implementation
 * Trace: SWE.1 SwRS-022 | SWE.2 SWD-CMP-017
 * ========================================================================== */
#include "variant.h"
#include "nvm_svc.h"

#define VARIANT_ID 0xB100u

Variant_t VAR_Get(void)
{
    Variant_t v = { .doors = 4u, .lin_enabled = false };
    (void)NVM_Read(VARIANT_ID, &v, sizeof(v));
    return v;
}
