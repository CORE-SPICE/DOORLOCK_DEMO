/* ==========================================================================
 * Unit: uds_srv (SWU-006)
 * Parent (SWE.2): SWD-CMP-006 Diagnostics UDS
 * Purpose: Minimal UDS dispatcher (0x10, 0x27 stub, 0x19, 0x31 actuator test)
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-009, SwRS-020, SwRS-027, SwRS-029 | SWE.2 SWD-CMP-006
 * ========================================================================== */
#ifndef UDS_SRV_H
#define UDS_SRV_H
#include "types.h"
#ifdef __cplusplus
extern "C" {
#endif

void UDS_Init(void);
void UDS_Dispatch(const CANMsg_t* req, CANMsg_t* resp);

#ifdef __cplusplus
}
#endif
#endif /* UDS_SRV_H */
