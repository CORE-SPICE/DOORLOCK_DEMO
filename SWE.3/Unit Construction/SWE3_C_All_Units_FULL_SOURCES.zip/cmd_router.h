/* ==========================================================================
 * Unit: cmd_router (SWU-002)
 * Parent (SWE.2): SWD-CMP-002 Command Router
 * Purpose: Priority-based command routing (RF > CAN > Local)
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-002, SwRS-018 | SWE.2 SWD-CMP-002
 * ========================================================================== */
#ifndef CMD_ROUTER_H
#define CMD_ROUTER_H

#include "types.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

void CMD_Init(void);
void CMD_PushRF(const RFFrame_t* f);
void CMD_PushCAN(const CANMsg_t* m);
void CMD_PushLocal(bool button_lock, bool button_unlock);
void CMD_Dispatch(void); /* Select highest-priority available command -> FSM */

#ifdef __cplusplus
}
#endif
#endif /* CMD_ROUTER_H */
