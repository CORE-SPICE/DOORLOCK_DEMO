/* ==========================================================================
 * Unit: fsm_core (SWU-001)
 * Parent (SWE.2): SWD-CMP-001 State Machine Core
 * Purpose: C implementation of Door Lock FSM (Locked/Transition/Unlocked)
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-001, SwRS-005, SwRS-018, SwRS-024 | SWE.2 SWD-CMP-001
 * ========================================================================== */
#ifndef FSM_CORE_H
#define FSM_CORE_H

#include "types.h"
#include "config.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    FSM_STATE_LOCKED = 0,
    FSM_STATE_TRANSITION,
    FSM_STATE_UNLOCKED
} fsm_state_t;

void FSM_Init(const Variant_t* cfg);
void FSM_HandleCommand(Cmd_t cmd);

/* Internal event hooks (invoked by other units) */
void FSM_OnOvercurrent(void);
void FSM_OnAck(bool success);

/* Crash/brown-out handling */
void FSM_ForceUnlock(void);

/* Test hooks */
#if TESTING
fsm_state_t FSM_EXPORT_STATE(void);
#endif

#ifdef __cplusplus
}
#endif

#endif /* FSM_CORE_H */
