/* ==========================================================================
 * Unit: dtc_mgr (SWU-007)
 * Parent (SWE.2): SWD-CMP-007 Fault & DTC Manager
 * Purpose: DTC creation, snapshot persistence to NVM service
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-014, SwRS-029, SwRS-030 | SWE.2 SWD-CMP-007
 * ========================================================================== */
#ifndef DTC_MGR_H
#define DTC_MGR_H
#include "types.h"
#ifdef __cplusplus
extern "C" {
#endif

void DTC_Set(uint16_t code, const Snapshot_t* snap);

#ifdef __cplusplus
}
#endif
#endif /* DTC_MGR_H */
