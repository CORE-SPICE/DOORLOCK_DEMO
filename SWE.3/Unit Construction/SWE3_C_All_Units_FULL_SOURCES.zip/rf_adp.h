/* ==========================================================================
 * Unit: rf_adp (SWU-013)
 * Parent (SWE.2): SWD-CMP-013 RF Receiver Adapter
 * Purpose: Parse raw RF payload into RFFrame_t (counter, payload, mac)
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-006, SwRS-013 | SWE.2 SWD-CMP-013
 * ========================================================================== */
#ifndef RF_ADP_H
#define RF_ADP_H
#include "types.h"
#include <stdbool.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

bool RF_Parse(const uint8_t* raw, size_t len, RFFrame_t* out);

#ifdef __cplusplus
}
#endif
#endif /* RF_ADP_H */
