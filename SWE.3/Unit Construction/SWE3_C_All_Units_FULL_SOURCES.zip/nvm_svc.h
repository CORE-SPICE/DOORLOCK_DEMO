/* ==========================================================================
 * Unit: nvm_svc (SWU-008)
 * Parent (SWE.2): SWD-CMP-008 NVM Service
 * Purpose: Atomic-like key/value storage (simple RAM-backed stub)
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-014, SwRS-021 | SWE.2 SWD-CMP-008
 * ========================================================================== */
#ifndef NVM_SVC_H
#define NVM_SVC_H
#include "types.h"
#include <stdbool.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

bool NVM_Write(uint32_t id, const void* data, size_t len);
bool NVM_Read(uint32_t id, void* data, size_t len);

#ifdef __cplusplus
}
#endif
#endif /* NVM_SVC_H */
