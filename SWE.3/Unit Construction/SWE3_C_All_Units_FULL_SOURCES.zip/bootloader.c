/* ==========================================================================
 * Unit: bootloader (SWU-016) - implementation
 * Trace: SWE.1 SwRS-012, SwRS-026 | SWE.2 SWD-CMP-016
 * ========================================================================== */
#include "bootloader.h"
#include "crypto.h"

static bool s_has_golden = true;

bool BL_Apply(const Image_t* img)
{
    if (!CRYPTO_VerifyImage(img)) {
        return s_has_golden; /* rollback to golden image (simulated) */
    }
    /* Apply image: in this stub, just return success */
    return true;
}
