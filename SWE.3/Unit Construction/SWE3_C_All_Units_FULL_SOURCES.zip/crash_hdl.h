/* ==========================================================================
 * Unit: crash_hdl (SWU-005)
 * Parent (SWE.2): SWD-CMP-005 Crash Handler
 * Purpose: Monitor crash/brown-out and force unlock path
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-007, SwRS-024 | SWE.2 SWD-CMP-005
 * ========================================================================== */
#ifndef CRASH_HDL_H
#define CRASH_HDL_H
#include "types.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

void CRASH_OnSignal(bool asserted); /* call on edge/periodic sample */

#ifdef __cplusplus
}
#endif
#endif /* CRASH_HDL_H */
