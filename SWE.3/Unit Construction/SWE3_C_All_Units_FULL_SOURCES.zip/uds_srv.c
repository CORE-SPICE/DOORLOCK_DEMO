/* ==========================================================================
 * Unit: uds_srv (SWU-006) - implementation
 * Trace: SWE.1 SwRS-009, SwRS-020, SwRS-027, SwRS-029 | SWE.2 SWD-CMP-006
 * ========================================================================== */
#include "uds_srv.h"
#include "dtc_mgr.h"
#include "act_mgr.h"
#include <string.h>

#define SID_DIAG_SESSION 0x10u
#define SID_SECURITY     0x27u
#define SID_READ_DTC     0x19u
#define SID_ROUTINE      0x31u

#define NRC_SUBFUNC_NOT_SUPPORTED 0x12u
#define NRC_GENERAL_REJECT        0x10u

void UDS_Init(void) {}

static void rsp_pos(const CANMsg_t* req, CANMsg_t* resp)
{
    memcpy(resp, req, sizeof(CANMsg_t));
    if (resp->dlc < 1u) resp->dlc = 1u;
    resp->data[0] = (uint8_t)(req->data[0] + 0x40u);
}

static void rsp_neg(const CANMsg_t* req, CANMsg_t* resp, uint8_t nrc)
{
    memcpy(resp, req, sizeof(CANMsg_t));
    resp->data[0] = 0x7Fu;
    resp->data[1] = req->data[0];
    resp->data[2] = nrc;
    resp->dlc = 3u;
}

void UDS_Dispatch(const CANMsg_t* req, CANMsg_t* resp)
{
    if (!req || !resp || req->dlc == 0u) return;
    switch (req->data[0]) {
    case SID_DIAG_SESSION: {
        rsp_pos(req, resp);
        resp->dlc = 2u;
        resp->data[1] = 0x03u; /* extended session */
        break;
    }
    case SID_SECURITY: {
        rsp_neg(req, resp, NRC_SUBFUNC_NOT_SUPPORTED); /* stub */
        break;
    }
    case SID_READ_DTC: {
        rsp_pos(req, resp);
        resp->dlc = 4u;
        resp->data[1] = 0x00u; /* status availability mask stub */
        resp->data[2] = 0x00u; /* no DTCs by default */
        resp->data[3] = 0x00u;
        break;
    }
    case SID_ROUTINE: {
        /* RoutineControl; assume subfunction 0x01 start; id selects lock/unlock test */
        if (req->dlc >= 3u) {
            uint8_t rid = req->data[2];
            if (rid == 0x01u) ACT_StartPulse(DIR_LOCK, 200u);
            else if (rid == 0x02u) ACT_StartPulse(DIR_UNLOCK, 200u);
            rsp_pos(req, resp);
            resp->dlc = 3u;
            resp->data[1] = req->data[1]; /* echo subfunction */
            resp->data[2] = rid;
        } else {
            rsp_neg(req, resp, NRC_GENERAL_REJECT);
        }
        break;
    }
    default:
        rsp_neg(req, resp, NRC_GENERAL_REJECT);
        break;
    }
}
