/* ==========================================================================
 * Unit: act_hal (SWU-015) - implementation
 * Trace: SWE.1 SwRS-003, SwRS-004, SwRS-005 | SWE.2 SWD-CMP-015
 * ========================================================================== */
#include "act_hal.h"

static Direction s_dir = DIR_LOCK;
static uint16_t s_current = 1000u;

void HAL_MotorDrive(Direction dir){ s_dir = dir; s_current = 1500u; }
void HAL_MotorStop(void){ s_current = 0u; }
uint16_t HAL_CurrentSense_mA(void){ return s_current; }
