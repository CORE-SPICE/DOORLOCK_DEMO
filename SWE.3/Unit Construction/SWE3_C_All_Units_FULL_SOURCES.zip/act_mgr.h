/* ==========================================================================
 * Unit: act_mgr (SWU-003)
 * Parent (SWE.2): SWD-CMP-003 Actuator Manager
 * Purpose: Actuator pulse control and overcurrent handling
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-004, SwRS-005, SwRS-020 | SWE.2 SWD-CMP-003
 * ========================================================================== */
#ifndef ACT_MGR_H
#define ACT_MGR_H

#include "types.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void ACT_StartPulse(Direction dir, uint16_t duration_ms);
void ACT_Stop(void);

/* Called from ISR/poll when overcurrent is detected */
void ACT_OnOvercurrentISR(void);

#if TESTING
void ACT_INJECT_OC(void);
#endif

#ifdef __cplusplus
}
#endif
#endif /* ACT_MGR_H */
