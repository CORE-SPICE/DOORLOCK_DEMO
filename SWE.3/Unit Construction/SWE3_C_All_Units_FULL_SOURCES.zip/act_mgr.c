/* ==========================================================================
 * Unit: act_mgr (SWU-003) - implementation
 * Trace: SWE.1 SwRS-004, SwRS-005, SwRS-020 | SWE.2 SWD-CMP-003
 * ========================================================================== */
#include "act_mgr.h"
#include "mcu_hal.h"
#include "dtc_mgr.h"
#include "fsm_core.h"
#include "act_hal.h"

static bool s_active = false;
static uint32_t s_deadline_ms = 0u;
static Direction s_dir = DIR_LOCK;

void ACT_StartPulse(Direction dir, uint16_t duration_ms)
{
    if (duration_ms < 200u) duration_ms = 200u;
    if (duration_ms > 500u) duration_ms = 500u;

    s_dir = dir;
    s_active = true;
    s_deadline_ms = HAL_GetTickMs() + duration_ms;
    HAL_MotorDrive(dir);
}

void ACT_Stop(void)
{
    HAL_MotorStop();
    s_active = false;
}

/* This should be called periodically (e.g., from a scheduler) */
static void act_mgr_tick(void)
{
    if (!s_active) return;

    if (HAL_CurrentSense_mA() > CAL_OC_THRESHOLD_MA) {
        ACT_OnOvercurrentISR();
        return;
    }

    if (HAL_GetTickMs() >= s_deadline_ms) {
        ACT_Stop();
        /* Notify FSM of success */
        FSM_OnAck(true);
    }
}

void ACT_OnOvercurrentISR(void)
{
    /* <50 ms stop path */
    ACT_Stop();
    /* Notify FSM for retry/DTC decision */
    FSM_OnOvercurrent();
}

#if TESTING
void ACT_INJECT_OC(void)
{
    ACT_OnOvercurrentISR();
}
#endif
