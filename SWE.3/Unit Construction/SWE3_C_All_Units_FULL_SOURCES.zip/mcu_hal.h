/* ==========================================================================
 * Unit: mcu_hal (SWU-014)
 * Parent (SWE.2): SWD-CMP-014 MCU HAL
 * Purpose: HAL stubs for tick, VBAT, watchdog
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-017, SwRS-023, SwRS-024 | SWE.2 SWD-CMP-014
 * ========================================================================== */
#ifndef MCU_HAL_H
#define MCU_HAL_H
#include "types.h"
#ifdef __cplusplus
extern "C" {
#endif

uint32_t HAL_GetTickMs(void);
uint16_t HAL_GetVBATmV(void);
void HAL_WatchdogKick(void);

#ifdef __cplusplus
}
#endif
#endif /* MCU_HAL_H */
