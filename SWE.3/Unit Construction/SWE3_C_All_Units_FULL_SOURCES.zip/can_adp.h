/* ==========================================================================
 * Unit: can_adp (SWU-011)
 * Parent (SWE.2): SWD-CMP-011 CAN Stack Adapter
 * Purpose: Validate incoming CAN FD frames (ID/DLC/sequence)
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-010, SwRS-019, SwRS-025 | SWE.2 SWD-CMP-011
 * ========================================================================== */
#ifndef CAN_ADP_H
#define CAN_ADP_H
#include "types.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

bool CAN_Validate(const CANMsg_t* m);

#ifdef __cplusplus
}
#endif
#endif /* CAN_ADP_H */
