/* ==========================================================================
 * Unit: ids (SWU-010)
 * Parent (SWE.2): SWD-CMP-010 IDS Engine
 * Purpose: Simple anomaly/replay detection for RF/CAN
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-013, SwRS-025, SwRS-030 | SWE.2 SWD-CMP-010
 * ========================================================================== */
#ifndef IDS_H
#define IDS_H

#include "types.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void IDS_Init(void);
void IDS_OnRF(const RFFrame_t* f);
void IDS_OnCAN(const CANMsg_t* m);

#if TESTING
void IDS_SET_THRESHOLD(uint8_t window);
#endif

#ifdef __cplusplus
}
#endif
#endif /* IDS_H */
