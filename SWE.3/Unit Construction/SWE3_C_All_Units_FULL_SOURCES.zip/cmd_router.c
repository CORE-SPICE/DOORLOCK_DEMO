/* ==========================================================================
 * Unit: cmd_router (SWU-002) - implementation
 * Trace: SWE.1 SwRS-002, SwRS-018 | SWE.2 SWD-CMP-002
 * ========================================================================== */
#include "cmd_router.h"
#include "fsm_core.h"
#include "ids.h"
#include "can_adp.h"

#define QSIZE 8u

typedef struct { Cmd_t buf[QSIZE]; uint8_t head, tail, count; } q_t;
static q_t q_rf, q_can, q_local;

static void q_init(q_t* q){ q->head=q->tail=q->count=0u; }
static bool q_push(q_t* q, Cmd_t c){
    if (q->count >= QSIZE) return false;
    q->buf[q->tail] = c; q->tail = (q->tail+1u)%QSIZE; q->count++; return true;
}
static bool q_pop(q_t* q, Cmd_t* c){
    if (q->count==0u) return false;
    *c = q->buf[q->head]; q->head=(q->head+1u)%QSIZE; q->count--; return true;
}

void CMD_Init(void)
{
    q_init(&q_rf); q_init(&q_can); q_init(&q_local);
}

void CMD_PushRF(const RFFrame_t* f)
{
    if (f == 0) return;
    IDS_OnRF(f);
    /* Simple mapping: even counter -> LOCK, odd -> UNLOCK (placeholder) */
    Cmd_t c = (f->counter & 1u) ? CMD_UNLOCK : CMD_LOCK;
    (void)q_push(&q_rf, c);
}

void CMD_PushCAN(const CANMsg_t* m)
{
    if (m == 0) return;
    if (!CAN_Validate(m)) return;
    /* Map ID to command (placeholder) */
    Cmd_t c = (m->id & 1u) ? CMD_UNLOCK : CMD_LOCK;
    (void)q_push(&q_can, c);
}

void CMD_PushLocal(bool button_lock, bool button_unlock)
{
    if (button_lock)  (void)q_push(&q_local, CMD_LOCK);
    if (button_unlock)(void)q_push(&q_local, CMD_UNLOCK);
}

void CMD_Dispatch(void)
{
    Cmd_t c;
    if (q_pop(&q_rf, &c) || q_pop(&q_can, &c) || q_pop(&q_local, &c)) {
        FSM_HandleCommand(c);
    }
}
