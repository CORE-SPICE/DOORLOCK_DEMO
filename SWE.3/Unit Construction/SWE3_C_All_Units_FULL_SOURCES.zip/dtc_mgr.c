/* ==========================================================================
 * Unit: dtc_mgr (SWU-007) - implementation
 * Trace: SWE.1 SwRS-014, SwRS-029, SwRS-030 | SWE.2 SWD-CMP-007
 * ========================================================================== */
#include "dtc_mgr.h"
#include "nvm_svc.h"
#include <string.h>

#define DTC_LOG_ID 0xA100u
#define MAX_DTC 16u
static DTC_t s_log[MAX_DTC];
static uint8_t s_count = 0u;

void DTC_Set(uint16_t code, const Snapshot_t* snap)
{
    if (s_count < MAX_DTC) {
        s_log[s_count].id = code;
        if (snap) {
            /* Store a compact snapshot */
            memcpy(s_log[s_count].snapshot, (const void*)snap, sizeof(s_log[s_count].snapshot));
            s_log[s_count].ts = snap->ts;
        } else {
            memset(s_log[s_count].snapshot, 0, sizeof(s_log[s_count].snapshot));
            s_log[s_count].ts = 0u;
        }
        s_count++;
    }
    /* Persist log head to NVM */
    (void)NVM_Write(DTC_LOG_ID, s_log, sizeof(s_log));
}
