/* ==========================================================================
 * Unit: can_adp (SWU-011) - implementation
 * Trace: SWE.1 SwRS-010, SwRS-019, SwRS-025 | SWE.2 SWD-CMP-011
 * ========================================================================== */
#include "can_adp.h"
#include <string.h>

#define MAX_ID 0x7FFu /* placeholder allowed range */
static uint8_t s_last_seq_table[16] = {0}; /* LUT by (id & 0xF) */

static bool id_allowed(uint32_t id)
{
    /* Placeholder policy: standard ID range only */
    return (id <= MAX_ID);
}

static bool crc_ok(const CANMsg_t* m)
{
    /* Placeholder CRC check stub: always true, to be replaced with real CRC */
    (void)m;
    return true;
}

bool CAN_Validate(const CANMsg_t* m)
{
    if (m == 0) return false;
    if (!id_allowed(m->id)) return false;
    if (m->dlc > 64u) return false;
    if (!crc_ok(m)) return false;

    uint8_t* pseq = &s_last_seq_table[m->id & 0xFu];
    uint8_t last = *pseq;
    if (m->seq == last) {
        return false; /* duplicate */
    }
    /* allow wrap-around; only reject if strictly older */
    if ((uint8_t)(m->seq - last) > 200u) {
        return false;
    }
    *pseq = m->seq;
    return true;
}
