/* ==========================================================================
 * Unit: mcu_hal (SWU-014) - implementation
 * Trace: SWE.1 SwRS-017, SwRS-023, SwRS-024 | SWE.2 SWD-CMP-014
 * ========================================================================== */
#include "mcu_hal.h"

static uint32_t s_tick = 0u;
static uint16_t s_vbat = 12000u;

uint32_t HAL_GetTickMs(void){ return s_tick++; }
uint16_t HAL_GetVBATmV(void){ return s_vbat; }
void HAL_WatchdogKick(void){ (void)0; }
