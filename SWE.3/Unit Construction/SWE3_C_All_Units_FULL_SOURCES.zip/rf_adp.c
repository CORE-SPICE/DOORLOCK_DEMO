/* ==========================================================================
 * Unit: rf_adp (SWU-013) - implementation
 * Trace: SWE.1 SwRS-006, SwRS-013 | SWE.2 SWD-CMP-013
 * ========================================================================== */
#include "rf_adp.h"
#include <string.h>

bool RF_Parse(const uint8_t* raw, size_t len, RFFrame_t* out)
{
    if (!raw || !out || len < 13u) return false;
    /* Format: [counter(3)][payload(8)][mac(4)] */
    out->counter = ((uint32_t)raw[0]<<16) | ((uint32_t)raw[1]<<8) | (uint32_t)raw[2];
    memcpy(out->payload, &raw[3], 8u);
    out->mac = ((uint32_t)raw[11]<<24) | ((uint32_t)raw[10]<<16) | ((uint32_t)raw[9]<<8) | (uint32_t)raw[8];
    return true;
}
