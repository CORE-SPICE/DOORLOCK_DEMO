/* ==========================================================================
 * Unit: in_filter (SWU-004)
 * Parent (SWE.2): SWD-CMP-004 Input Filter
 * Purpose: Debounce and duplicate suppression for digital inputs
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-003 | SWE.2 SWD-CMP-004
 * ========================================================================== */
#ifndef IN_FILTER_H
#define IN_FILTER_H
#include "types.h"
#include "config.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

bool IN_DebounceTick(bool raw); /* call at 1 ms tick */

#ifdef __cplusplus
}
#endif
#endif /* IN_FILTER_H */
