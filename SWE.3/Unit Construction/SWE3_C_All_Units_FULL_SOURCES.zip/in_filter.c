/* ==========================================================================
 * Unit: in_filter (SWU-004) - implementation
 * Trace: SWE.1 SwRS-003 | SWE.2 SWD-CMP-004
 * ========================================================================== */
#include "in_filter.h"

static uint8_t hist = 0x00u;
static bool stable = false;
static uint16_t counter_ms = 0u;

bool IN_DebounceTick(bool raw)
{
    /* 8-sample shift register filter + time window */
    hist = (uint8_t)((hist << 1) | (raw ? 1u : 0u));
    if (hist == 0x00u) {
        if (!stable) {
            if (counter_ms >= CAL_DEBOUNCE_MS) { stable = false; counter_ms = 0u; }
            else { counter_ms++; }
        } else { stable = false; counter_ms = 0u; }
    } else if (hist == 0xFFu) {
        if (stable) {
            if (counter_ms >= CAL_DEBOUNCE_MS) { stable = true; counter_ms = 0u; }
            else { counter_ms++; }
        } else { stable = true; counter_ms = 0u; }
    } else {
        counter_ms = 0u;
    }
    return stable;
}
