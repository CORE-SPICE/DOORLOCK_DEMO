/* ==========================================================================
 * Unit: act_hal (SWU-015)
 * Parent (SWE.2): SWD-CMP-015 Actuator Driver HAL
 * Purpose: Low-level motor drive, stop, and current sense interface
 * ASIL: A | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-003, SwRS-004, SwRS-005 | SWE.2 SWD-CMP-015
 * ========================================================================== */
#ifndef ACT_HAL_H
#define ACT_HAL_H
#include "types.h"
#ifdef __cplusplus
extern "C" {
#endif

void HAL_MotorDrive(Direction dir);
void HAL_MotorStop(void);
uint16_t HAL_CurrentSense_mA(void);

#ifdef __cplusplus
}
#endif
#endif /* ACT_HAL_H */
