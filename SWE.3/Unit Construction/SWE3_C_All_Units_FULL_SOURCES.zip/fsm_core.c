/* ==========================================================================
 * Unit: fsm_core (SWU-001) - implementation
 * Trace: SWE.1 SwRS-001, SwRS-005, SwRS-018, SwRS-024 | SWE.2 SWD-CMP-001
 * ========================================================================== */
#include "fsm_core.h"
#include "act_mgr.h"
#include "mcu_hal.h"
#include "dtc_mgr.h"

/* Local context */
static fsm_state_t s_state = FSM_STATE_LOCKED;
static uint8_t s_retry_count = 0U;
static uint32_t s_pulse_deadline_ms = 0U;
static Variant_t s_cfg;

/* Forward decls */
static void start_pulse(Direction dir, uint16_t dur_ms);
static void to_state(fsm_state_t st);

void FSM_Init(const Variant_t* cfg)
{
    if (cfg != 0) {
        s_cfg = *cfg;
    } else {
        s_cfg.doors = 4u;
        s_cfg.lin_enabled = false;
    }
    s_state = FSM_STATE_LOCKED;
    s_retry_count = 0u;
    s_pulse_deadline_ms = 0u;
}

void FSM_HandleCommand(Cmd_t cmd)
{
    switch (s_state) {
    case FSM_STATE_LOCKED:
        if (cmd == CMD_UNLOCK) {
            start_pulse(DIR_UNLOCK, CAL_PULSE_MS_UNLOCK);
            to_state(FSM_STATE_TRANSITION);
        }
        break;
    case FSM_STATE_UNLOCKED:
        if (cmd == CMD_LOCK) {
            start_pulse(DIR_LOCK, CAL_PULSE_MS_LOCK);
            to_state(FSM_STATE_TRANSITION);
        }
        break;
    case FSM_STATE_TRANSITION: /* ignore new commands while busy */
    default:
        break;
    }

    /* Handle timeout while in TRANSITION */
    if (s_state == FSM_STATE_TRANSITION && HAL_GetTickMs() >= s_pulse_deadline_ms) {
        /* assume success on timeout if no OC occurred */
        s_retry_count = 0u;
        to_state(FSM_STATE_UNLOCKED);
    }
}

void FSM_OnOvercurrent(void)
{
    /* <50 ms stop is handled by act_mgr; here we decide retry or DTC */
    if (s_state != FSM_STATE_TRANSITION) {
        return;
    }
    s_retry_count++;
    if (s_retry_count <= 3u) {
        /* For simplicity, always try unlock on retry */
        start_pulse(DIR_UNLOCK, CAL_PULSE_MS_UNLOCK);
    } else {
        Snapshot_t snap = {0};
        snap.ts = HAL_GetTickMs();
        snap.current_mA = 0u;
        snap.voltage_mV = HAL_GetVBATmV();
        snap.state = (uint8_t)s_state;
        DTC_Set(0x0101u, &snap); /* OC_FAIL */
        s_retry_count = 0u;
        to_state(FSM_STATE_LOCKED); /* fail-safe: back to locked */
    }
}

void FSM_OnAck(bool success)
{
    if (s_state != FSM_STATE_TRANSITION) return;
    s_retry_count = 0u;
    if (success) {
        /* flip state */
        to_state((HAL_GetTickMs() & 1u) ? FSM_STATE_UNLOCKED : FSM_STATE_LOCKED);
    } else {
        /* treat as OC path to retry/DTC */
        FSM_OnOvercurrent();
    }
}

void FSM_ForceUnlock(void)
{
    /* Crash/brown-out path */
    ACT_Stop();
    start_pulse(DIR_UNLOCK, CAL_PULSE_MS_UNLOCK);
    to_state(FSM_STATE_UNLOCKED);
}

static void start_pulse(Direction dir, uint16_t dur_ms)
{
    if (dur_ms < 200u) dur_ms = 200u;
    if (dur_ms > 500u) dur_ms = 500u;
    s_pulse_deadline_ms = HAL_GetTickMs() + (uint32_t)dur_ms;
    ACT_StartPulse(dir, dur_ms);
}

static void to_state(fsm_state_t st)
{
    s_state = st;
    HAL_WatchdogKick();
}

#if TESTING
fsm_state_t FSM_EXPORT_STATE(void) { return s_state; }
#endif
