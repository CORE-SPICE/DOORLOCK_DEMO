/* ==========================================================================
 * Unit: crypto (SWU-009)
 * Parent (SWE.2): SWD-CMP-009 Secure Boot & Crypto
 * Purpose: Image signature verification stub (to be backed by HW accel)
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-011, SwRS-012, SwRS-026 | SWE.2 SWD-CMP-009
 * ========================================================================== */
#ifndef CRYPTO_H
#define CRYPTO_H
#include "types.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

bool CRYPTO_VerifyImage(const Image_t* img);

#if TESTING
void CRYPTO_INJECT_FAIL(void);
#endif

#ifdef __cplusplus
}
#endif
#endif /* CRYPTO_H */
