/* ==========================================================================
 * Unit: lin_adp (SWU-012) - implementation
 * Trace: SWE.1 SwRS-015 | SWE.2 SWD-CMP-012
 * ========================================================================== */
#include "lin_adp.h"
#include <string.h>

static uint8_t rxbuf[16];
static size_t rxlen = 0u;

void LIN_If_Tx(const uint8_t* data, size_t len)
{
    (void)data; (void)len; /* stub: no-op */
}

size_t LIN_If_Rx(uint8_t* data, size_t maxlen)
{
    size_t n = (rxlen < maxlen) ? rxlen : maxlen;
    memcpy(data, rxbuf, n);
    rxlen = 0u;
    return n;
}
