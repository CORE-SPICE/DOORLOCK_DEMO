/* ==========================================================================
 * Unit: nvm_svc (SWU-008) - implementation
 * Trace: SWE.1 SwRS-014, SwRS-021 | SWE.2 SWD-CMP-008
 * ========================================================================== */
#include "nvm_svc.h"
#include <string.h>

#define NVM_SLOTS 8u
typedef struct { uint32_t id; uint8_t buf[256]; size_t len; } slot_t;
static slot_t slots[NVM_SLOTS];

static int find_slot(uint32_t id)
{
    for (int i=0;i<NVM_SLOTS;i++){ if (slots[i].id == id) return i; }
    return -1;
}
static int alloc_slot(uint32_t id)
{
    int idx = find_slot(id);
    if (idx >= 0) return idx;
    for (int i=0;i<NVM_SLOTS;i++){ if (slots[i].id == 0u){ slots[i].id = id; return i; } }
    return -1;
}

bool NVM_Write(uint32_t id, const void* data, size_t len)
{
    if (!data || len > sizeof(slots[0].buf)) return false;
    int idx = alloc_slot(id);
    if (idx < 0) return false;
    memcpy(slots[idx].buf, data, len);
    slots[idx].len = len;
    return true;
}

bool NVM_Read(uint32_t id, void* data, size_t len)
{
    int idx = find_slot(id);
    if (idx < 0 || len > slots[idx].len) return false;
    memcpy(data, slots[idx].buf, len);
    return true;
}
