/* ==========================================================================
 * Unit: crypto (SWU-009) - implementation
 * Trace: SWE.1 SwRS-011, SwRS-012, SwRS-026 | SWE.2 SWD-CMP-009
 * ========================================================================== */
#include "crypto.h"
static bool force_fail = false;

bool CRYPTO_VerifyImage(const Image_t* img)
{
    if (!img || !img->data || img->len == 0u) return false;
    if (force_fail) return false;
    /* Placeholder: accept if simple parity of bytes equals img->crc LSB */
    uint32_t acc = 0u;
    for (uint32_t i=0;i<img->len;i++){ acc += img->data[i]; }
    return ((acc & 0xFFu) == (img->crc & 0xFFu));
}

#if TESTING
void CRYPTO_INJECT_FAIL(void){ force_fail = true; }
#endif
