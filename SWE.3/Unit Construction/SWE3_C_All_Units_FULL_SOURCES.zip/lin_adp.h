/* ==========================================================================
 * Unit: lin_adp (SWU-012)
 * Parent (SWE.2): SWD-CMP-012 LIN Adapter
 * Purpose: Simple Tx/Rx stubs with internal buffer
 * ASIL: QM | Cybersecurity Relevant: No
 * Trace: SWE.1 SwRS-015 | SWE.2 SWD-CMP-012
 * ========================================================================== */
#ifndef LIN_ADP_H
#define LIN_ADP_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

void LIN_If_Tx(const uint8_t* data, size_t len);
size_t LIN_If_Rx(uint8_t* data, size_t maxlen);

#ifdef __cplusplus
}
#endif
#endif /* LIN_ADP_H */
