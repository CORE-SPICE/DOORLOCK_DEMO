/* ==========================================================================
 * Unit: crash_hdl (SWU-005) - implementation
 * Trace: SWE.1 SwRS-007, SwRS-024 | SWE.2 SWD-CMP-005
 * ========================================================================== */
#include "crash_hdl.h"
#include "fsm_core.h"
#include "mcu_hal.h"
#include "dtc_mgr.h"

static bool last = false;

void CRASH_OnSignal(bool asserted)
{
    if (asserted && !last) {
        /* Rising edge: force unlock and log */
        Snapshot_t snap = {0};
        snap.ts = HAL_GetTickMs();
        snap.voltage_mV = HAL_GetVBATmV();
        snap.current_mA = 0u;
        snap.state = 0u;
        DTC_Set(0x0301u, &snap); /* CRASH_EVT */
        FSM_ForceUnlock();
    }
    last = asserted;
}
