/* ==========================================================================
 * Unit: bootloader (SWU-016)
 * Parent (SWE.2): SWD-CMP-016 Bootloader
 * Purpose: Apply verified image with rollback
 * ASIL: QM | Cybersecurity Relevant: Yes
 * Trace: SWE.1 SwRS-012, SwRS-026 | SWE.2 SWD-CMP-016
 * ========================================================================== */
#ifndef BOOTLOADER_H
#define BOOTLOADER_H
#include "types.h"
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif

bool BL_Apply(const Image_t* img);

#ifdef __cplusplus
}
#endif
#endif /* BOOTLOADER_H */
